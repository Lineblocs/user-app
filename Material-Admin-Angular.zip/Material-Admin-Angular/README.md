## Material Dashboard Admin Angular Theme

Thanks for purchasing the Material Dashboard Admin Angular Theme.

Follow the documentation to install and get started with the development:

  - Link to documentation: http://material-admin-angular.strapui.com/#/dashboard/docs
  - Live Demo URL: http://material-admin-angular.strapui.com/
  - Product URL: http://www.strapui.com/themes/material-dashboard-admin-angular/

Happy coding!
